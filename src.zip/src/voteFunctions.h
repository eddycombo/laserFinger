

static void simpleVote(int a, int b ){

    cout<<a<<endl;


};
