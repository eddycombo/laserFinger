#ifndef POSITIONVOTE_H_INCLUDED
#define POSITIONVOTE_H_INCLUDED


#include "ofMain.h"
#include "ofxCvTrackedBlob.h"

class positionVote{

    public:

    positionVote();
    ~positionVote();

    void setup();

    void draw();

    void setChoicesLocations(int x, int y, int w, int h);
    void clearChoicesLocations();

    ofRectangle getWinner(vector <ofxCvTrackedBlob> *onScreenPointers);

    private:

    int numChoices;

    vector <int> candidates;

    vector<ofRectangle> choicesLocations;
    vector<ofxCvTrackedBlob> *pointersOnScreen;

    void checkPointersLocation(int locationIndex, ofxCvTrackedBlob *pointerToCheck);

};

#endif



