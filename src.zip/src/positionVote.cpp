#include "positionVote.h"

positionVote::positionVote(){};
positionVote::~positionVote(){};


void positionVote::setChoicesLocations(int x, int y, int w, int h){

    ofRectangle tempRect;
    tempRect.x = x;
    tempRect.y = y;
    tempRect.width = w;
    tempRect.height = h;

    this->choicesLocations.push_back(tempRect);
    this->numChoices++ ;
    this->candidates.push_back(0);

};

void positionVote::clearChoicesLocations(){

    this->choicesLocations.clear();
    this->numChoices=0;
    this->candidates.clear();

};


ofRectangle positionVote::getWinner(vector<ofxCvTrackedBlob> *onScreenPointers){
    ///check where's everybody;
    ///could also fisrt check if pointer is in the controls area before checking into wich button it is

    for(int i = 0; i<onScreenPointers->size(); i++){

            for(int j = 0; j<this->choicesLocations.size(); j++){

                    if(this->choicesLocations[j].inside(onScreenPointers->at(i).centroid)){

                        this->candidates[j]++;

                    };
            };
    };

    ///then get the index of max of candidates to get a winner.

    int maxIndex = 0;

    for (int i=1; i<this->candidates.size(); i++) {
        if (this->candidates[i] > this->candidates[maxIndex]) {
            maxIndex = i;
        }
    }
    return this->choicesLocations[maxIndex];

};
