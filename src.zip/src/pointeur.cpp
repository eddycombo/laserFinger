#include "pointeur.h"

pointeur::pointeur(){

x = y = -1;



}

pointeur::pointeur(int ids, int xs, int ys, float sizes){
id = ids;
x = xs;
y = ys;
size = sizes;


}

